

<?php $__env->startSection('title', 'PagInici'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Buscar futbolistes:</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/jugadors/jugador" method="GET">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
            <label for="" class="from-label">Selecciona la forma de bsuqueda:  </label>
            <br>
            <select id="forma" name="forma" onchange="preguntes();">
                <option>Nom</option>
                <option>Posicio</option>
                <option>Edat</option>
            </select>
    </div>

    <div id="contingut" class="mb-3">
    
    <div class="mb-3">
        <label for="" class="from-label">Nom jugador: </label>
        <input id="nom" name="nom" type="text" class="form-control" tabindex="1">
    </div>
    
    </div>

    <button type="submit" class="btn btn-primary"  tabindex="4">Buscar</button>
<form>
<table id="contactes" class="table table-dark table-striped shadow-lg mt-4">
        <thead class="bg-primary text-white">
        <tr>
            <th scope="col">Nom</th>
            <th scope="col">Edat</th>
            <th scope="col">Posicio</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $jugadors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($jugador -> nom); ?></td>
            <td><?php echo e($jugador -> edat); ?></td>
            <td><?php echo e($jugador -> posicio); ?></td>
           
      
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
function preguntes(){
        let cbxForma = document.getElementById('forma');
        let forma = cbxForma.value;

        if (forma == "Nom"){
            document.getElementById('contingut').innerHTML = ' <label for="" class="from-label">Nom: </label> <input id="nom" name="nom" type="text" class="form-control" tabindex="1">';
        }else if(forma == "Edat"){
            document.getElementById('contingut').innerHTML = ' <label for="" class="from-label">Edat </label> <input id="edat" name="edat" type="text" class="form-control" tabindex="3">';
        }else if(forma == "Posicio"){
            document.getElementById('contingut').innerHTML = ' <label for="" class="from-label">Posicio:  </label>  <br><select id="posicio" name="posicio"> <option>POR</option>' +
              '  <option>LD</option>' +
             '   <option>DFC</option>'+
              '  <option>LI</option>'+
               ' <option>MCD</option>'+
              '  <option>MC</option>'+
              '  <option>MCO</option>'+
               ' <option>MD</option>'+
               ' <option>MI</option>'+
                '<option>EI</option>'+
               ' <option>ED</option>'+
               ' <option>SD</option>'+
                '<option>DC</option> '+
            '</select>';
        }
       

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\AppFutbolistes\resources\views/buscarFutbolistes.blade.php ENDPATH**/ ?>