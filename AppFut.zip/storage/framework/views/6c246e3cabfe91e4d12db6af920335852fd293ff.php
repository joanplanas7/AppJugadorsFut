

<?php $__env->startSection('title', 'PagInici'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Pàgina Inici</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <p>En aquesta pàgina podreu buscar jugadors que tinc guardats a la base de dades, també podreu introduir nous jugadors a la base de dades. </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\AppFutbolistes\resources\views/pagInici/index.blade.php ENDPATH**/ ?>