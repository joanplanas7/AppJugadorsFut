@extends('adminlte::page')

@section('title', 'PagInici')

@section('content_header')
    <h1>Pàgina Inici</h1>
@stop

@section('content')
   <p>En aquesta pàgina podreu buscar jugadors que tinc guardats a la base de dades, també podreu introduir nous jugadors a la base de dades. </p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop