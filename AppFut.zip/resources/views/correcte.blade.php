@extends('adminlte::page')

@section('title', 'PagInici')

@section('content_header')
    <h1>Has afegit el jugador correctament. </h1>
@stop

@section('content')
 

@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop